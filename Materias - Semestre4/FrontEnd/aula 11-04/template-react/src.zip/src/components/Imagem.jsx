// export function Imagem(props) {
export function Imagem({ recurso }) {

   const urlPadrao = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSgVfHORQFLyUf_rNove-xUmxIskDeMJ63REz_YIMQ6S0vCyQdkBvJos4igKspvCgpqnpy8h0xM--1uckzZIxDgyoHy37-MowkF-YzvVx8";
   // caso não receba o recurso, deve usar a urlPadrão

   return (
      <>
         <img 
            // src={recurso != undefined ?  recurso : urlPadrao} 
            src={recurso || urlPadrao} 
            style={{width: '300px'}} 
            alt="" 
         />
      </>
   ); 
}