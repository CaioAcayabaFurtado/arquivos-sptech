export function Button ({ desabilitado }) {
   const estiloDesabilitado = { backgroundColor: "#B2b2b2", color: "red" }
   
   return (
      <>
         <button 
            disabled={desabilitado} 
            style={ desabilitado && estiloDesabilitado } 
            // style={desabilitado ? estiloDesabilitado : undefined} 
            onClick={() => { alert("Clicou") }}
            >
            Clique em mim!
         </button>
      </>
   )
}