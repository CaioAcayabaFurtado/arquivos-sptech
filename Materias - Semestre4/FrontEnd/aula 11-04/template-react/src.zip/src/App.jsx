import { Button } from "./components/Button";
import { Imagem } from "./components/Imagem";

function App() {
 return (
  <>
   <Imagem recurso="https://static.vecteezy.com/ti/fotos-gratis/t2/26525162-leao-animal-isolado-foto.jpg" />
   <Imagem recurso="https://static.todamateria.com.br/upload/pi/ng/pinguim01-cke.jpg" />
   <Imagem />
   <Imagem />
   <Button desabilitado={true}/>
   <Button /> 
  </>
 );
}

export default App;
