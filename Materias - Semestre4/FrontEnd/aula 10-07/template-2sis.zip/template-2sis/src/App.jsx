export default function App () {
  return (
    <>
      <h1 className="bg-red-500">Componente App.jsx</h1>
    </>
  )
}