package sptech.projetoc2.controller

import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import sptech.projetoc2.entity.Pugilista
import sptech.projetoc2.repository.PugilistaRepository
import kotlin.test.assertEquals
import kotlin.test.assertNotNull

@SpringBootTest
class AplicationTest {

    @Autowired
    lateinit var controller: PugilistaController

    @Autowired
    lateinit var repository: PugilistaRepository

    @Test
    fun contextLoads() {
        assertNotNull(controller)
        assertNotNull(repository)
    }

    @Test
    fun testCartel() {
        val p = Pugilista(
            nome = "Rocky ${System.currentTimeMillis()}",
            peso = 99.5,
            categoria = "Pesado",
            vitoriasPontos = 3,
            vitoriasNocaute = 7,
            empates = 1,
            derrotasPontos = 1,
            derrotasNocaute = 0,
            aposentado =  true
        )

        val savedP = repository.save(p)

        val cartel = repository.getCartel(savedP.codigo!!)

        assertEquals(savedP.codigo,  cartel.codigo)
        assertEquals(p.nome, cartel.nome)
        assertEquals(p.vitoriasNocaute, cartel.vitoriasNocaute)
        assertEquals(p.vitoriasPontos+ p.vitoriasNocaute, cartel.vitorias)
        assertEquals(p.derrotasPontos+ p.derrotasNocaute, cartel.derrotas)
        assertEquals(p.empates, cartel.empates)
    }
}