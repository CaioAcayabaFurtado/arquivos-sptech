package sptech.projetoc2.controller

import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNull
import org.junit.jupiter.api.Test
import org.mockito.Mockito.*
import org.springframework.http.HttpStatus
import sptech.projetoc2.dtos.CartelPugilistaResponse
import sptech.projetoc2.entity.Pugilista
import sptech.projetoc2.repository.PugilistaRepository

class PugilistaControllerTest {

    private val repository = mock(PugilistaRepository::class.java)
    private val controller = PugilistaController(repository)

    @Test
    fun post_createsNewPugilistaAndReturns201() {
        val novoPugilista = Pugilista(1, "John Doe", "Heavyweight", 102.0, 10)
        `when`(repository.save(novoPugilista)).thenReturn(novoPugilista)

        val response = controller.post(novoPugilista)

        assertEquals(HttpStatus.CREATED, response.statusCode)
        assertEquals(novoPugilista, response.body)
        verify(repository).save(novoPugilista)
    }

    @Test
    fun get_returnsPugilistaByCodigoWhenExists() {
        val pugilista = Pugilista(1, "John Doe", "Heavyweight", 102.0, 10)
        `when`(repository.existsById(1)).thenReturn(true)
        `when`(repository.findById(1)).thenReturn(java.util.Optional.of(pugilista))

        val response = controller.get(1)

        assertEquals(HttpStatus.OK, response.statusCode)
        assertEquals(pugilista, response.body)
    }

    @Test
    fun get_returns404WhenPugilistaDoesNotExist() {
        `when`(repository.existsById(1)).thenReturn(false)

        val response = controller.get(1)

        assertEquals(HttpStatus.NOT_FOUND, response.statusCode)
        assertNull(response.body)
    }

    @Test
    fun get_returnsFilteredPugilistasByNomeAndCategoria() {
        val pugilistas = listOf(Pugilista(1, "John Doe", "Heavyweight", 102.0, 10))
        `when`(repository.findByNomeIgnoreCaseContainsAndCategoriaIgnoreCase("John", "Heavyweight"))
            .thenReturn(pugilistas)

        val response = controller.get("John", "Heavyweight")

        assertEquals(HttpStatus.OK, response.statusCode)
        assertEquals(pugilistas, response.body)
    }

    @Test
    fun get_returnsEmptyListFilteredPugilistasByNomeAndCategoria() {
        `when`(repository.findByNomeIgnoreCaseContainsAndCategoriaIgnoreCase("John", "Heavyweight"))
            .thenReturn(emptyList<Pugilista>())

        val response = controller.get("John", "Heavyweight")

        assertEquals(HttpStatus.NO_CONTENT, response.statusCode)
        assertNull(response.body)
    }

    @Test
    fun get_returnsFilteredPugilistasByNome() {
        val pugilistas = listOf(Pugilista(1, "John Doe", "Heavyweight", 102.0, 10))
        `when`(repository.findByNomeIgnoreCaseContains("John")).thenReturn(pugilistas)

        val response = controller.get("John", null)

        assertEquals(HttpStatus.OK, response.statusCode)
        assertEquals(pugilistas, response.body)
    }

    @Test
    fun get_returnsEmptyFilteredPugilistasByNome() {
        `when`(repository.findByNomeIgnoreCaseContains("John")).thenReturn(emptyList<Pugilista>())

        val response = controller.get("John", null)

        assertEquals(HttpStatus.NO_CONTENT, response.statusCode)
        assertNull(response.body)
    }

    @Test
    fun get_returnsFilteredPugilistasByCategoria() {
        val pugilistas = listOf(Pugilista(1, "John Doe", "Heavyweight", 102.0, 10))
        `when`(repository.findByCategoriaIgnoreCase("Heavyweight")).thenReturn(pugilistas)

        val response = controller.get(null, "Heavyweight")

        assertEquals(HttpStatus.OK, response.statusCode)
        assertEquals(pugilistas, response.body)
    }

    @Test
    fun get_returnsEmptyFilteredPugilistasByCategoria() {
        `when`(repository.findByCategoriaIgnoreCase("Heavyweight")).thenReturn(emptyList<Pugilista>())

        val response = controller.get(null, "Heavyweight")

        assertEquals(HttpStatus.NO_CONTENT, response.statusCode)
        assertNull(response.body)
    }

    @Test
    fun get_returnsAllPugilistasWhenNoQueryParameters() {
        `when`(repository.findAll()).thenReturn(emptyList<Pugilista>())

        val response = controller.get(null, null)

        assertEquals(HttpStatus.NO_CONTENT, response.statusCode)
        assertNull(response.body)
    }

    @Test
    fun get_returns204WhenNoPugilistasFound() {
        `when`(repository.findAll()).thenReturn(emptyList())

        val response = controller.get(null, null)

        assertEquals(HttpStatus.NO_CONTENT, response.statusCode)
        assertNull(response.body)
    }

    @Test
    fun delete_removesPugilistaWhenExists() {
        `when`(repository.existsById(1)).thenReturn(true)

        val response = controller.delete(1)

        assertEquals(HttpStatus.NO_CONTENT, response.statusCode)
        verify(repository).deleteById(1)
    }

    @Test
    fun delete_returns404WhenPugilistaDoesNotExist() {
        `when`(repository.existsById(1)).thenReturn(false)

        val response = controller.delete(1)

        assertEquals(HttpStatus.NOT_FOUND, response.statusCode)
    }

    @Test
    fun update_updatesPugilistaWithCorrectCodigo() {
        val existingPugilista = Pugilista(1, "John Doe", "Heavyweight", 102.0, 10)
        val updatedPugilista = Pugilista(2, "John Doe Updated", "Heavyweight", 102.0, 15)
        val expectedPugilista = updatedPugilista.copy(codigo = 1)
        `when`(repository.existsById(1)).thenReturn(true)
        `when`(repository.save(expectedPugilista)).thenReturn(expectedPugilista)

        val response = controller.update(1, updatedPugilista)

        assertEquals(HttpStatus.OK, response.statusCode)
        assertEquals(expectedPugilista, response.body)
    }

    @Test
    fun update_doesNotUpdateWhenCodigoDoesNotExist() {
        `when`(repository.existsById(1)).thenReturn(false)

        val response = controller.update(1, mock(Pugilista::class.java))

        assertEquals(HttpStatus.NOT_FOUND, response.statusCode)
        assertNull(response.body)
    }

    @Test
    fun getCartel_returnsCartelWhenPugilistaExists() {
        val cartel = mock(CartelPugilistaResponse::class.java)

        `when`(repository.existsById(1)).thenReturn(true)
        `when`(repository.getCartel(1)).thenReturn(cartel)

        val response = controller.getCartel(1)

        assertEquals(HttpStatus.OK, response.statusCode)
        assertEquals(cartel, response.body)
    }

    @Test
    fun get_cartel_returns404WhenPugilistaDoesNotExist() {
        `when`(repository.existsById(1)).thenReturn(false)

        val response = controller.getCartel(1)

        assertEquals(HttpStatus.NOT_FOUND, response.statusCode)
        assertNull(response.body)
    }
}