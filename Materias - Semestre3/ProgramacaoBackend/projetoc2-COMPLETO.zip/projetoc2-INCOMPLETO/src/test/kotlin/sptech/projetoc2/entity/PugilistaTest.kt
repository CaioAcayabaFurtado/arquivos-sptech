package sptech.projetoc2.entity

import jakarta.persistence.Entity
import jakarta.validation.Validation
import jakarta.validation.Validator
import jakarta.validation.constraints.*
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import kotlin.reflect.full.findAnnotation
import kotlin.reflect.jvm.javaField

class PugilistaAnnotationsTest {

    private lateinit var validator: Validator

    @BeforeEach
    fun setUp() {
        validator = Validation.buildDefaultValidatorFactory().validator
    }

    @Test
    fun class_hasEntityAnnotation() {
        val annotation = Pugilista::class.findAnnotation<Entity>()
        assertNotNull(annotation, "A classe Pugilista deve ter a anotação @Entity")
    }

    @Test
    fun atributes_haveAnnotation() {
        var notBlank = Pugilista::nome.javaField!!.getDeclaredAnnotation(NotBlank::class.java)
        assertNotNull(notBlank)

        val size = Pugilista::nome.javaField!!.getDeclaredAnnotation(Size::class.java)
        assertNotNull(size)
        assertEquals(1, size.min)
        assertEquals(20, size.max)

        notBlank = Pugilista::categoria.javaField!!.getDeclaredAnnotation(NotBlank::class.java)
        assertNotNull(notBlank)

        val notNull = Pugilista::peso.javaField!!.getDeclaredAnnotation(NotNull::class.java)
        assertNotNull(notNull)

        val decimalMin = Pugilista::peso.javaField!!.getDeclaredAnnotation(DecimalMin::class.java)
        assertNotNull(decimalMin)
        assertEquals("50.0", decimalMin.value)

        var positiveOrZero = Pugilista::vitoriasNocaute.javaField!!.getDeclaredAnnotation(PositiveOrZero::class.java)
        assertNotNull(positiveOrZero)

        positiveOrZero = Pugilista::vitoriasPontos.javaField!!.getDeclaredAnnotation(PositiveOrZero::class.java)
        assertNotNull(positiveOrZero)

        positiveOrZero = Pugilista::empates.javaField!!.getDeclaredAnnotation(PositiveOrZero::class.java)
        assertNotNull(positiveOrZero)

        positiveOrZero = Pugilista::derrotasNocaute.javaField!!.getDeclaredAnnotation(PositiveOrZero::class.java)
        assertNotNull(positiveOrZero)

        positiveOrZero = Pugilista::derrotasPontos.javaField!!.getDeclaredAnnotation(PositiveOrZero::class.java)
        assertNotNull(positiveOrZero)

    }
}