INSERT INTO pugilista (
    nome, categoria, peso, vitorias_nocaute, vitorias_pontos, empates, derrotas_nocaute, derrotas_pontos, aposentado
) VALUES
('Anderson Silva', 'Peso Médio', 84.0, 23, 4, 0, 2, 1, false),
('Anderson Silva Jr', 'Peso Médio', 84.0, 2, 0, 0, 2, 1, false),
('Mike Tyson', 'Peso Pesado', 100.0, 44, 5, 0, 6, 0, true),
('Manny Pacquiao', 'Peso Meio-Médio', 66.7, 39, 23, 2, 3, 2, false),
('Ronda Rousey', 'Peso Galo', 61.2, 12, 0, 0, 2, 0, true),
('Conor McGregor', 'Peso Leve', 70.3, 19, 1, 0, 4, 0, false),
('Floyd Mayweather', 'Peso Meio-Médio', 68.0, 27, 23, 0, 0, 0, true),
('Amanda Nunes', 'Peso Pena', 65.8, 13, 4, 0, 2, 0, false);