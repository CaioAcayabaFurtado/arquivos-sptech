interface UsuarioGadgets {
    fun equiparGadget(gadget:String):String{
        return gadget
    }
    fun usarGadget():String{
        return "DescGadget"
    }
}