import org.apache.commons.dbcp2.BasicDataSource
import org.springframework.dao.EmptyResultDataAccessException
import org.springframework.jdbc.core.BeanPropertyRowMapper
import org.springframework.jdbc.core.JdbcTemplate

class MusicaRepositorio {
    lateinit var jdbcTemplate: JdbcTemplate
    fun configurar() {
        val dataSource = BasicDataSource()
        dataSource.driverClassName = "org.h2.Driver"
        dataSource.url = "jdbc:h2:mem:Spot4You"
        dataSource.username = "sa"
        dataSource.password = ""
        jdbcTemplate = JdbcTemplate(dataSource)
    }
    fun criarTabela() {
        jdbcTemplate.execute(
            """
        create table if not exists Musica(
        id int primary key auto_increment,
        titulo varchar(45) not null,
        artista varchar(45) not null,
        album varchar(45) not null,
        duracao int,
        disponivel boolean
        )
        """.trimIndent()
        )
    }
    fun inserir(novaMusica: Musica): Boolean {
        if (novaMusica.titulo.isBlank() || novaMusica.artista.isBlank() || novaMusica.album.isBlank()) {
            return false
        }
        val qtdLinhasAfetadas = jdbcTemplate.update(
            """
                insert into Musica (titulo, artista, album, duracao, disponivel) values
                (?, ?, ?, ?, ?)
            """,
            novaMusica.titulo,
            novaMusica.artista,
            novaMusica.album,
            novaMusica.duracao,
            novaMusica.disponivel
        )
        return qtdLinhasAfetadas > 0;
    }
    fun listar(): List<Musica> {
        return jdbcTemplate.query(
            "select * from Musica",
            BeanPropertyRowMapper(Musica::class.java)
        )
    }
    fun existePorId(id: Int): Boolean {
        val qtdEncontrado = jdbcTemplate.queryForObject(
            "select count(*) from Musica where id = ?",
            Int::class.java,
            id
        )
        return qtdEncontrado > 0
    }
    fun buscarPorId(id: Int): Musica? {
        return try {
            jdbcTemplate.queryForObject(
                "select * from Musica where id = ?",
                BeanPropertyRowMapper(Musica::class.java),
                id
            )
        } catch (e: EmptyResultDataAccessException) {
            null
        }
    }
    fun atualizarPorId(id: Int, musica: Musica): Boolean {
        val qtdLinhasAfetadas = jdbcTemplate.update(
            """
                update Musica set
                titulo = ?,
                artista = ?,
                album = ?,
                duracao = ?,
                disponivel = ?
                WHERE id = ?
            """,
            musica.titulo,
            musica.artista,
            musica.album,
            musica.duracao,
            musica.disponivel,
            id
        )
        return qtdLinhasAfetadas > 0
    }
    fun deletarPorId(id: Int): Boolean {
        val qtdLinhasAfetadas = jdbcTemplate.update(
            "delete from Musica where id = ?",
            id
        )
        return qtdLinhasAfetadas > 0
    }
    fun disponivelPorId(id: Int): Boolean {
        return jdbcTemplate.queryForObject(
            "select disponivel from Musica where id = ?",
            Boolean::class.java,
            id
        )
    }
    fun tornarDisponivelPorId(id: Int): Boolean {
        val qtdLinhasAfetadas = jdbcTemplate.update(
            """
                update Musica set disponivel = true where id = ?
            """,
            id
        )
        return qtdLinhasAfetadas > 0
    }
}