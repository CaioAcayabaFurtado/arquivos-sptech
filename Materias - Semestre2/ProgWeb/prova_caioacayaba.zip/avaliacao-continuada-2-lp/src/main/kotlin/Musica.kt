class Musica {
    var id: Int = 0
    var titulo: String = ""
        private set
    var artista: String = ""
        private set
    var album: String = ""
        private set
    var duracao: Int = 0 // número de minutos
        private set
    var disponivel: Boolean = false
        private set
    fun setTitulo(novoValor: String) {
        if (novoValor.length >= 2) {
            titulo = novoValor
        }
    }
    fun setArtista(novoValor: String) {
        if (novoValor.length >= 2) {
            artista = novoValor
        }
    }
    fun setAlbum(novoValor: String) {
        if (novoValor.length >= 2) {
            album = novoValor
        }
    }
    fun setDuracao(novoValor: Int) {
        if (novoValor >= 30) {
            duracao = novoValor
        }
    }
    fun setDisponivel(novoValor: Boolean) {
        disponivel = novoValor
    }
    fun converterDuracaoEmMinutos(): String {
        val minutos = duracao / 60
        val segundos = duracao % 60
        return "${minutos.toString().padStart(2, '0')}:${segundos.toString().padStart(2, '0')}" // exibir sempre com 2 dígitos
    }
}